package SeleniumAssignment;

public class Q14thQ15th_CSSXpath {
	
	//CSS Selectors
	
		PIM
		 
		 div.menu:nth-child(2) ul.main-menu-first-level-unordered-list.main-menu-first-level-unordered-list-width li.current.main-menu-first-level-list-item:nth-child(2) a.firstLevelMenu:nth-child(1) > b:nth-child(1)
		  
		 Time 
		 div.menu:nth-child(2) ul.main-menu-first-level-unordered-list.main-menu-first-level-unordered-list-width li.main-menu-first-level-list-item:nth-child(4) a.firstLevelMenu:nth-child(1) > b:nth-child(1)
		 
		 Maintanance
		 div.menu:nth-child(2) ul.main-menu-first-level-unordered-list.main-menu-first-level-unordered-list-width li.main-menu-first-level-list-item:nth-child(10) a.firstLevelMenu:nth-child(1) > b:nth-child(1)
		 
		 Apply Leave
		 div.box:nth-child(3) div.inner div.outerbox.no-border:nth-child(1) div.maincontent.group-wrapper div.panel_wrapper div.panel_draggable.panel-preview fieldset.panel_resizable.panel-preview table.quickLaungeContainer tbody:nth-child(1) tr:nth-child(1) td:nth-child(1) > div.quickLaunge
		 
		 Time sheets
		 div.box:nth-child(3) div.inner div.outerbox.no-border:nth-child(1) div.maincontent.group-wrapper div.panel_wrapper div.panel_draggable.panel-preview fieldset.panel_resizable.panel-preview table.quickLaungeContainer tr:nth-child(1) td:nth-child(3) div.quickLaunge a:nth-child(1) > span.quickLinkText:nth-child(2)
		 
		  
		 EMP disribution by submit
		 div.box:nth-child(3) div.inner div.outerbox.no-border:nth-child(2) div.maincontent.group-wrapper div.panel_wrapper div.panel_draggable.panel-preview:nth-child(1) fieldset.panel_resizable.panel-preview div:nth-child(2) div:nth-child(5) > canvas.flot-overlay:nth-child(2)
		
		
		//Xpaths
		
		Market place 
		//input[@id='MP_link']
		 
		Welcome Admin
		//a[@id='welcome']
		 
		Admin
		//b[contains(text(),'Admin')]
		  
		 Leave List 
		 //span[contains(text(),'Leave List')]

}
